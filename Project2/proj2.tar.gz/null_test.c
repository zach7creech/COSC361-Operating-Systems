#include "types.h"
#include "user.h"
#define NULL (void *)0x0

int
main()
{
  int* null = NULL;

  //dereferencing this null ptr should fire trap
  *null = 0;

  exit();
}

#include "types.h"
#include "user.h"
#include "mmu.h"

int
main()
{
  int* n;
	
  //sbrk an integer then sbrk another page-size of memory
  n = (int *)sbrk(0);
  sbrk(PGSIZE);
  
  //set the integer's value then protect it
  *n = 0;
  mprotect(n, 1);

  /* 
     This was before I tested if fork was working probably. Uncomment this
     and comment the fork() if statement to test the single thread.
  
  *n = 1;
  printf(1, "Somehow successfully set! Exiting...\n");

  munprotect(n, 1)
  *n = 1;
  printf(1, "Successfully set! Exiting...\n");
  
  */

  //fork the process, the parent and child's respective copies of the integer
  //should both be read-only at this point
  if(fork() == 0)
  {
    //have the child correctly unprotect then modify
    printf(1, "Child unprotecting and setting to 1\n");
    munprotect(n, 1);
    *n = 1;
    printf(1, "Child successfully set! Exiting...\n");
    exit();
  }
  else
  {
    //have the parent try to modify without protecting, resulting in a trap
    wait();
    printf(1, "Parent about to attempt set, trap should fire and next message from parent will not appear\n");
    *n = 1;
    printf(1, "Parent somehow successfully set! Exiting...\n");
    exit();
  }

  exit();
}

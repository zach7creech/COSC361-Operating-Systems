#include "types.h"
#include "user.h"
#include "pstat.h"

int main()
{
  int pid1, pid2, pid3;
  
  settickets(25);

  pid1 = fork();

  if(pid1 != 0)
  {
    pid2 = fork();

    if(pid2 != 0)
    {
      pid3 = fork();

      if(pid3 == 0)
      {
        settickets(30);
	while(1);
      }
    }
    else
    {
      settickets(20);
      while(1);
    }
  }
  else
  {
    settickets(10);
    while(1);
  }

  while(1)
  {
    struct pstat ps;
    getpinfo(&ps);
    sleep(1000);
  }
}
